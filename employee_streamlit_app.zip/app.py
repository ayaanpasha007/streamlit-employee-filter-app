import streamlit as st
import pandas as pd

st.title("Employee Salary Filter App")

df = pd.read_csv("employees.csv", on_bad_lines="skip")

st.write("Employee Data")
st.dataframe(df)

filtered = df[df["Salary"] > 50000]
st.write("Employees with Salary > 50000")
st.dataframe(filtered)

role = st.selectbox("Select Role",
                    ["Data Scientist", "Developer", "Manager"])

if role == "Data Scientist":
    st.success("You analyze data and build ML models")
elif role == "Developer":
    st.success("You develop applications")
else:
    st.success("You manage teams")
